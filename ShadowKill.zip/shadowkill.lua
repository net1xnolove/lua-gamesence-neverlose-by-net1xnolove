-- Упрощенная таблица
local body = { [1] = "Head", [2] = "Chest", [3] = "Stomach" }

client.set_event_callback("player_hurt", function(e)
    -- Получаем тебя и того, в кого попали
    local me = entity.get_local_player()
    local attacker = client.userid_to_entindex(e.attacker)
    local victim = client.userid_to_entindex(e.userid)

    -- Если стрелял ТЫ
    if attacker == me and victim ~= me then
        local damage = e.dmg_health
        local hitgroup = e.hitgroup
        local part = body[hitgroup] or "Body"
        local name = entity.get_player_name(victim) or "Enemy"

        -- Сообщение
        local str = string.format("[ShadowKill] Hit %s in %s for %d", name, part, damage)

        -- 1. Сначала ПРОВЕРЯЕМ В КОНСОЛИ (нажми ~)
        print(str)

        -- 2. Пробуем отправить в чат через принудительный вызов
        client.exec("say ", str)
    end
end)

-- Добавим проверку промаха (Aim Miss)
client.set_event_callback("aim_miss", function(e)
    local name = entity.get_player_name(e.target) or "Enemy"
    local str = "[ShadowKill] Missed " .. name .. " due to " .. (e.reason or "spread")
    
    print(str)
    client.exec("say ", str)
end)

-- Эта строчка появится в консоли СРАЗУ при загрузке скрипта
print(">>> ShadowKill Script Loaded! <<<")